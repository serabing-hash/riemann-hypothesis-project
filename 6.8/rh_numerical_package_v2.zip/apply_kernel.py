import numpy as np
from numpy.fft import rfft, irfft

def apply_E_band(a, N, bandwidth):
    idx = np.arange(1, N+1)
    b = a[1:] / np.sqrt(idx)
    u = np.log(idx)
    U = np.linspace(u.min(), u.max(), N)
    bU = np.interp(U, u, b)

    du = U[1]-U[0]
    W = max(1, int(bandwidth))
    t = np.arange(-W, W+1)*du
    k = np.exp(-0.5*np.abs(t))

    L = len(bU) + len(k) - 1
    L2 = 1<< (L-1).bit_length()
    B = np.zeros(L2); K = np.zeros(L2)
    B[:len(bU)] = bU
    K[:len(k)] = k
    conv = irfft(rfft(B)*rfft(K))[:L]
    conv_centered = conv[W:W+len(bU)]

    yU = conv_centered
    y = np.zeros(N+1)
    y[1:] = np.interp(u, U, yU) * np.sqrt(idx)
    return y
