import numpy as np

def nystrom_correction(a, N, r=256, seed=123):
    rng = np.random.default_rng(seed)
    J = rng.integers(1, N+1, size=r)
    Jv = J.astype(float)
    W = np.minimum(np.sqrt(Jv[:,None]/Jv[None,:]), np.sqrt(Jv[None,:]/Jv[:,None]))
    n = np.arange(1, N+1, dtype=float)
    C = np.minimum(np.sqrt(n[:,None]/Jv[None,:]), np.sqrt(Jv[None,:]/n[:,None]))
    Winv = np.linalg.pinv(W)
    return C @ (Winv @ (C.T @ a[1:]))
