# RH Numerical Package

This package provides tools to test the Nyman–Beurling/Báez-Duarte criterion numerically.

## Files

- `compute_mu.py`: Generate Möbius function up to N.
- `build_coeffs.py`: Construct coefficients a_n with smooth cutoff and slow weight.
- `apply_kernel.py`: Apply band-limited kernel operator in log-space (FFT accelerated).
- `nystrom.py`: Low-rank Nyström correction for off-band terms.
- `solve_nb_bd.py`: Matrix-free solver with Conjugate Gradient.
- `analyze_theta.py`: Estimate theta exponent and standard error.
- `run_experiment.py`: Example run for N=100k, outputs CSV.
- `make_plots.py`: Generate plots and theta fits from CSV.

## Usage

```bash
python run_experiment.py
python make_plots.py
```

This will create:
- `results_exp.csv`: Results table
- `scaling.png`: MSE vs N
- `theta_fit.png`: log-log regression showing theta
```  
