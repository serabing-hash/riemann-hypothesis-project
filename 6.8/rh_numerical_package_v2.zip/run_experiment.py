import numpy as np
from compute_mu import mobius_upto
from build_coeffs import build_a
from solve_nb_bd import LinearOp, cg

def run(N=100000, lam=1e-3, bandwidth=3000, nystrom_rank=256):
    mu = mobius_upto(N)
    a = build_a(np.array(mu), N)
    op = LinearOp(N, lam, bandwidth, nystrom_rank)
    b = np.ones_like(a)  # placeholder RHS, 실제는 weight integral 기반
    sol, iters = cg(op, b, iters=500, tol=1e-6)
    mse = np.mean((op.matvec(sol)-b)**2)
    print(f"N={N}, MSE={mse}, iters={iters}")
    with open("results_exp.csv","w") as f:
        f.write("N,lambda,bandwidth,rank,mse,iters\n")
        f.write(f"{N},{lam},{bandwidth},{nystrom_rank},{mse},{iters}\n")

if __name__ == "__main__":
    run()
