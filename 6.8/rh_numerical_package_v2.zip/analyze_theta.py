import numpy as np

def fit_theta(N_list, mse_list):
    x = np.log(np.log(np.array(N_list, dtype=float)))
    y = np.log(np.array(mse_list, dtype=float))
    X = np.c_[np.ones_like(x), -x]
    beta = np.linalg.lstsq(X, y, rcond=None)[0]
    alpha, theta = beta[0], beta[1]
    resid = y - X@beta
    s2 = (resid@resid)/(len(x)-2)
    cov = s2 * np.linalg.inv(X.T@X)
    se_theta = np.sqrt(cov[1,1])
    return theta, se_theta
