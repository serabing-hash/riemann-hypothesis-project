def mobius_upto(N: int):
    mu = [1]*(N+1)
    is_prime = [True]*(N+1)
    primes = []
    mu[0] = 0
    for i in range(2, N+1):
        if is_prime[i]:
            primes.append(i)
            mu[i] = -1
        for p in primes:
            x = i*p
            if x > N: break
            is_prime[x] = False
            if i % p == 0:
                mu[x] = 0
                break
            else:
                mu[x] = -mu[i]
    return mu
