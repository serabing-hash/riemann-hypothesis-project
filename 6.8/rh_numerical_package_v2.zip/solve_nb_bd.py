import numpy as np
from apply_kernel import apply_E_band
from nystrom import nystrom_correction

class LinearOp:
    def __init__(self, N, lam, bandwidth, nystrom_rank=None):
        self.N = N; self.lam = lam
        self.bandwidth = bandwidth
        self.nystrom_rank = nystrom_rank

    def matvec(self, a):
        y = a.copy()
        y += self.lam * a
        y += apply_E_band(a, self.N, self.bandwidth)
        if self.nystrom_rank:
            corr = nystrom_correction(a, self.N, r=self.nystrom_rank)
            y[1:] += corr
        return y

def cg(op, b, iters=500, tol=1e-6):
    x = np.zeros_like(b)
    r = b - op.matvec(x)
    p = r.copy()
    rs = r@r
    for k in range(iters):
        Ap = op.matvec(p)
        alpha = rs / (p@Ap + 1e-30)
        x += alpha * p
        r -= alpha * Ap
        rs_new = r@r
        if np.sqrt(rs_new) < tol: break
        p = r + (rs_new/rs) * p
        rs = rs_new
    return x, k
