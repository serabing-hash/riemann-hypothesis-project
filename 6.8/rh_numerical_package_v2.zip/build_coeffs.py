import numpy as np

def smooth_cutoff(x):
    y = np.zeros_like(x)
    mask = (x>0) & (x<1)
    z = x[mask]*(1-x[mask])
    y[mask] = np.exp(-1.0/np.maximum(z, 1e-300))
    y /= y.max() if y.max()>0 else 1.0
    return y

def q_slow(n, N, C=2.0):
    lnN = np.log(N)
    return (lnN**C) * (1 + 0.1*np.sin(2*np.pi*np.log(np.maximum(n,2))/lnN))

def build_a(mu, N):
    n = np.arange(N+1, dtype=float)
    x = n/N
    v = smooth_cutoff(x)
    q = q_slow(n, N)
    a = mu * v * q
    return a
