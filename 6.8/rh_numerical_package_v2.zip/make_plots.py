import pandas as pd
import matplotlib.pyplot as plt
from analyze_theta import fit_theta

df = pd.read_csv("results_exp.csv")
N = df['N'].values
mse = df['mse'].values

theta, se_theta = fit_theta(N, mse)
print(f"theta={theta:.4f} ± {se_theta:.4f}")

plt.figure()
plt.loglog(N, mse, 'o-', label="MSE")
plt.xlabel("N")
plt.ylabel("MSE")
plt.title("Scaling of MSE vs N")
plt.legend()
plt.savefig("scaling.png")

plt.figure()
import numpy as np
x = np.log(np.log(N))
y = np.log(mse)
plt.plot(x, y, 'o', label="data")
coef = np.polyfit(x, y, 1)
plt.plot(x, np.polyval(coef, x), '-', label=f"slope={-coef[0]:.3f}")
plt.xlabel("log log N")
plt.ylabel("log MSE")
plt.legend()
plt.title("Theta estimation")
plt.savefig("theta_fit.png")
